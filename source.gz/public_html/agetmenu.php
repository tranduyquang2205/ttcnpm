<?php
include 'config.php';
$type= $_GET['type'];
if($type==0){
    $sql="SELECT * FROM menu"; 
}else{
$sql="SELECT * FROM menu WHERE type = '$type'"; }
$result = mysqli_query($conn,$sql);      
while($menu = mysqli_fetch_assoc($result)){
    if($menu['type']==1){
        $type="Món cơm";
    }else
     if($menu['type']==2){
        $type="Món mì";
    }else
     if($menu['type']==3){
        $type="Món nước";
    }else
     if($menu['type']==4){
        $type="Đồ uống";
    }
    
$price =number_format($menu['price'],0,",",".").' vnđ';
print '
			    					<li>
						<figure><img src="'.$menu['image'].'" alt=""></figure>
						<h4>'.$menu['name'].' <i class="pending">'.$price.'</i></h4>
						<p><a href="#" class="btn_1 gray"><i class="fa fa-fw fa-envelope"></i> '.$type.'</a></p>
						<ul class="buttons">
							<li><a href="updateitem.php?id='.$menu['id'].'" class="btn_1 gray approve"><i class="fa fa-fw fa-check-circle-o"></i> Chỉnh sửa</a></li>
							<li><a href="delitem.php?id='.$menu['id'].'" class="btn_1 gray delete"><i class="fa fa-fw fa-times-circle-o"></i> Xóa</a></li>
						</ul>
					</li>
';}
?>