<footer>
		<div class="container">
		</div>
	</footer>
	<!--/footer-->

	<div id="toTop"></div><!-- Back to top button -->
	
	<div class="layer"></div><!-- Opacity Mask Menu Mobile -->
	
	<!-- Sign In Modal -->
	<div id="sign-in-dialog" class="zoom-anim-dialog mfp-hide">
		<div class="modal_header">
			<h3>Đăng nhập</h3>
		</div>
		<form name="login" action="login.php" method="post">
			<div class="sign-in-wrapper">
				<a href="#0" class="social_bt facebook">Đăng nhập với Facebook</a>
				<a href="#0" class="social_bt google">Đăng nhập với Google</a>
				<div class="divider"><span>Hoặc</span></div>
				<div class="form-group">
					<label>Username</label>
					<input type="text" class="form-control" name="username" id="email">
					<i class="icon_mail_alt"></i>
				</div>
				<div class="form-group">
					<label>Mật khẩu</label>
					<input type="password" class="form-control" name="password" id="password" value="">
					<i class="icon_lock_alt"></i>
				</div>
				<div class="clearfix add_bottom_15">
					<div class="checkboxes float-left">
						<label class="container_check">Giữ đăng nhập
						  <input type="checkbox">
						  <span class="checkmark"></span>
						</label>
					</div>
					<div class="float-right mt-1"><a id="forgot" href="javascript:void(0);">Quên mật khẩu?</a></div>
				</div>
				<div class="text-center">
					<input type="submit" value="Đăng nhập" class="btn_1 full-width mb_5">
					Chưa có tài khoản? <a href="sign-up.php">Đăng kí</a>
				</div>
			</div>
		</form>
		<!--form -->
	</div>
	<!-- /Sign In Modal -->
	
	<!-- COMMON SCRIPTS -->
    <script src="js/common_scripts.min.js"></script>
    <script src="js/common_func.js"></script>
    <script src="assets/validate.js"></script>

</body>
</html>