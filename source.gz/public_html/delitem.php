<?php
include 'config.php';
$id = $_GET['id'];
$update = "DELETE FROM `menu` WHERE id='$id'";
$result = mysqli_query($conn,$update);
if(!$result ) {
      echo 'Could not delete data: ';
   }
   
      echo ("<script LANGUAGE='JavaScript'>
    window.alert('Xóa thành công');
    window.location.href='./admin.php';
    </script>");
    
?>