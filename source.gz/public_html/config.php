<?php
   if(!isset($_SESSION))
   {
       session_start();
   }
$host='103.130.216.98';
$user='xacchet1_admin';
$password='dqxkv2205';
$database='xacchet1_data';
$conn=mysqli_connect($host, $user, $password, $database);

?>