<?php
include 'config.php';
$type= $_GET['type'];
if($type==-1){
    $sql="SELECT * FROM cart"; 
}else{
$sql="SELECT * FROM cart WHERE status = '$type'"; }
$result = mysqli_query($conn,$sql);      
while($menu = mysqli_fetch_assoc($result)){
    if($menu['status']==0){
        $type="Đang chờ";
        $kkk="pending";
    }else
     if($menu['status']==1){
        $type="Đã xong";
        $kkk="approved";
    }else
     if($menu['status']==2){
        $type="Đã hủy";
        $kkk="cancel";
    }
$price =number_format($menu['price'],0,",",".").' vnđ';
print '
					<li>
						<figure><img src="img/item_1.jpg" alt=""></figure>
						<h4>'.$menu['uname'].'<i class="'.$kkk.'">'.$type.'</i></h4>
						<ul class="booking_list">
							<li><strong>'.$menu['name'].'</strong> </li>
              <li><strong>'.$price.'</strong> x '.$menu['sl'].' </li>
							<li>'.number_format($menu['price']*$menu['sl'],0,",",".").' vnđ</li>
						</ul>
						<ul class="buttons">
							<li><a href="updateorder.php?id='.$menu['id'].'&status=1" class="btn_1 gray approve"><i class="fa fa-fw fa-check-circle-o"></i> Xong</a></li>
							<li><a href="updateorder.php?id='.$menu['id'].'&status=2" class="btn_1 gray delete"><i class="fa fa-fw fa-times-circle-o"></i> Hủy</a></li>
						</ul>
					</li>
';}
?>