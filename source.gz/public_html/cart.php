<?php
include 'config.php';
   if(isset($_SESSION['admin']))
   {
      if(($_SESSION['admin'])==1)
   {
      header("Location: ./admin.php");
   }
   }
include 'function.php';
include 'header.php';
?>
<main>
		<div class="container margin_60_40" style="padding-top:100px">
			<div class="row">
				<div class="col-12">
					<div class="main_title version_2">
						<span><em></em></span>
						<h2>Xác nhận đặt món</h2>
					</div>
				</div>
				<div class="col-md-6">
					<div class="list_home">
						<ul>
<?php getcheckout($_SESSION['id'],$conn) ?>
						</ul>
					</div>
				</div>
			</div>

		</div>

		
	</main>
	<?php
	include 'footer.php';
	?>