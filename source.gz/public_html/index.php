<?php
include 'config.php';
   if(isset($_SESSION['admin']))
   {
      if(($_SESSION['admin'])==1)
   {
      header("Location: ./admin.php");
   }
   }
include 'function.php';
include 'header.php';
?>
	<main>	
		<div class="bg_gray">
			<div class="container margin_60_40">
				<div class="main_title center">
					<span><em></em></span>
					<h2>BkFood Canteen</h2>
					<p>Vui lòng chọn đồ ăn</p>
				</div>
				<!-- /main_title -->
				<div class="owl-carousel owl-theme categories_carousel">
					<div class="item">
						<a href="#0">
							<span>5</span>
							<i class="icon-food_icon_pizza"></i>
							<h3>Các món cơm</h3>
						</a>
					</div>
					<div class="item">
						<a href="#0">
							<span>5</span>
							<i class="icon-food_icon_chinese"></i>
							<h3>Các món mì</h3>
						</a>
					</div>
					<div class="item">
						<a href="#0">
							<span>5</span>
							<i class="icon-food_icon_burgher"></i>
							<h3>Món nước</h3>
						</a>
					</div>
					<div class="item">
						<a href="#0">
							<span>4</span>
							<i class="icon-food_icon_vegetarian"></i>
							<h3>Đồ uống</h3>
						</a>
					</div>
					<div class="item">
						<a href="#0">
							<span>2</span>
							<i class="icon-food_icon_cake_2"></i>
							<h3>Tráng miệng</h3>
						</a>
					</div>
				</div>
				<!-- /carousel -->
			</div>
			<!-- /container -->
		</div>
		<!-- /bg_gray -->
		
		<div class="container margin_60_40" style="padding-bottom:0px!important">
			<div class="main_title">
				<span><em></em></span>
				<h2>Các món cơm</h2>
				
			</div>

			<div class="owl-carousel owl-theme carousel_4">
                <?php getmenu(1,$conn); ?>
			</div>
			
		</div>	
		<div class="container margin_60_40" style="padding-top:0px!important">
			<div class="main_title">
				<span><em></em></span>
				<h2>Các món mỳ</h2>
			</div>

			<div class="owl-carousel owl-theme carousel_4">
<?php getmenu(2,$conn); ?>
			</div>
			
		</div>	
		<div class="container margin_60_40" style="padding-top:0px!important">
			<div class="main_title">
				<span><em></em></span>
				<h2>Các món nước</h2>
				
			</div>

			<div class="owl-carousel owl-theme carousel_4">
<?php getmenu(3,$conn); ?>
			</div>
			
		</div>	
		<div class="container margin_60_40" style="padding-top:0px!important">
			<div class="main_title">
				<span><em></em></span>
				<h2>Đồ uống</h2>
			</div>
			<div class="owl-carousel owl-theme carousel_4">
			    <?php getmenu(4,$conn); ?>
			</div>
		</div>	
		<div class="container margin_60_40" style="padding-top:0px!important">
			<div class="main_title">
				<span><em></em></span>
				<h2>Tráng miệng</h2>
			</div>
			<div class="owl-carousel owl-theme carousel_4">
			    <?php getmenu(5,$conn); ?>
			</div>
		</div>
	</main>
	
<script>
var cart =<?php 
if(!isset($_SESSION['cart'])){echo "0";}
else
{ echo $_SESSION['cart'];} ?>;
function addtocart(mid,uid){
    if(uid==-1){
        toastr.info('Vui lòng đăng nhập trước')
    }else{
    $.ajax({
        url:"addtocart.php",
        type: "POST",
        data:{
            "mid": mid,
            "uid": uid,
        },
        success:function(data)
        {
            cart++;
            document.getElementById("cartn").innerHTML=cart;
           toastr.success('Đã thêm vào giỏ')
        }
      });}
}    
    
</script>	
	<!-- /main -->
	<?php
include 'footer.php';
?>