<?php
include 'config.php';
$name = $_POST['name'];
$type = $_POST['type'];
$price = $_POST['price'];
$image = $_POST['image'];


$insert = "INSERT INTO `menu` (name, type, price,image)
  VALUES ('$name', '$type', '$price', '$image')";
$result = mysqli_query($conn,$insert);

if(!$result ) {
      echo 'Could not update data: ';
   }else{
   echo ("<script LANGUAGE='JavaScript'>
    window.alert('Thêm thành công');
    window.location.href='./additem.php';
   </script>");}
    
?>