<?php
include 'config.php';
   if(!isset($_SESSION['admin']))
   {
      header("Location: ./index.php");
   }
 if(!isset($_GET['id'])){
          header("Location: ./index.php");
}
$id=$_GET['id'];
$status=$_GET['status'];
$update = "UPDATE  `cart` SET
status='$status'
WHERE id='$id'";
$result1 = mysqli_query($conn,$update);
if(!$result1 ) {
      echo 'Could not update data: ';
   }else{
   echo ("<script LANGUAGE='JavaScript'>
    window.alert('Thành công');
    window.location.href='./order.php';
   </script>");}
?>