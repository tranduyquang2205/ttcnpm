<?php
   include 'aheader.php';
include 'config.php';
include 'function.php';
   if(!isset($_SESSION['admin']))
   {
      header("Location: ./index.php");
   }
   ?>

  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="admin/#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Danh sách món</li>
      </ol>
		<div class="box_general">
			<div class="header_box">
				<h2 class="d-inline-block">Danh sách món</h2>
				<div class="filter">
					<select name="orderby" onchange="agetmenu(this.value)" class="selectbox">
						<option value="0">Tất cả các món</option>
						<option value="1">Cơm</option>
						<option value="2">Mì</option>
						<option value="3">Món nước</option>
						<option value="4">Đồ uống</option>
						<option value="5">Tráng miệng</option>
					</select>
				</div>
			</div>
			<div class="list_general">
				<ul id="txtHint">
				</ul>
			</div>
		</div>
		<!-- /box_general-->
		<!-- /pagination-->
	  </div>
	  <!-- /container-fluid-->
   	</div>
    <!-- /container-wrapper-->
    <script>
function agetmenu(str) {
  var xhttp;
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("txtHint").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "agetmenu.php?type="+str, true);
  xhttp.send();
}
agetmenu(0)
</script>    
<?php
   include 'afooter.php';
?>