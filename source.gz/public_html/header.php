
<!DOCTYPE html>
<html lang="vi">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="content-language" content="vi" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Foogra - Discover & Book the best restaurants at the best price">
    <meta name="author" content="Ansonika">
    <title>BkFood</title>

    <!-- Favicons-->
    <link rel="shortcut icon" href="img/logo.png" type="image/x-icon">
    <link rel="apple-touch-icon" type="image/x-icon" href="img/apple-touch-icon-57x57-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="img/apple-touch-icon-72x72-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="img/apple-touch-icon-114x114-precomposed.png">
    <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="img/apple-touch-icon-144x144-precomposed.png">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400&display=swap" rel="stylesheet">
    <!-- GOOGLE WEB FONT -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700&display=swap" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <!-- BASE CSS -->
    <link href="css/bootstrap_customized.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
     <link href="css/detail-page.css" rel="stylesheet">
      <link href="css/booking-sign_up.css" rel="stylesheet">
      <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet"/>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

    <!-- SPECIFIC CSS -->
    <link href="css/home.css" rel="stylesheet">

    <!-- YOUR CUSTOM CSS -->
    <link href="css/custom.css" rel="stylesheet">

</head>

<body>
				
	<header class="header clearfix element_to_stick sticky">
		<div class="container">
		<div id="logo">
			<a href="/">
				<img src="img/logo.png" width="50"  alt="" class="logo_normal">
				<img src="img/logo.png" width="50"  alt="" class="logo_sticky">
			</a>
		</div>
		<ul id="top_menu"><?php
		    				if(isset($_SESSION['admin']))
   {
print'<li><a href="logout.php"  class="login">Đăng xuất</a></li>';
   }else{
       		print'	<li><a href="#sign-in-dialog" id="sign-in" class="login">Sign In</a></li>';
   }
?>
		<a href="cart.php">	<li><i style="font-size:25px!important;padding-top:5px!important" class="icon_cart_alt" title="Your wishlist"></i></li></a>
			<span class="btn_1"><strong style="color:red" id="cartn"><?php   
			if(isset($_SESSION['cart'])){
			        echo $_SESSION['cart'];
			}else{echo "0";} ?>
			
			
			</strong></span>
		</ul>
		<!-- /top_menu -->
		<a href="#0" class="open_close">
			<i class="icon_menu"></i><span>Menu</span>
		</a>
		<nav class="main-menu">
			<div id="header_menu">
				<a href="#0" class="open_close">
					<i class="icon_close"></i><span>Menu</span>
				</a>
				<a href="/"><img src="img/logo.png" width="140" height="35" alt=""></a>
			</div>
			<ul>
				<?php 
				if(isset($_SESSION['admin']))
   {
print'				<li><a href="#0">'.$_SESSION['name'].'</a></li>';
   }
				?>

			</ul>
		</nav>
	</div>
	</header>
	<!-- /header -->