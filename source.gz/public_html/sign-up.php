<?php
include 'config.php';
   if(isset($_SESSION['admin']))
   {
      header("Location: ./index.php");
   }
   include 'header.php';
  if(isset($_POST['name'])) {
$name = $_POST['name'];
$email = $_POST['email'];
$username = $_POST['username'];
$password = $_POST['password'];


$insert = "INSERT INTO `user` (name, email, username,password)
  VALUES ('$name', '$email', '$username', '$password')";
$result = mysqli_query($conn,$insert);

if(!$result ) {
      echo 'Could not update data: ';
   }else{
   echo ("<script LANGUAGE='JavaScript'>
    window.alert('Đăng kí thành công');
    window.location.href='./additem.php';
   </script>");}
      
      
      
      
  }
   ?>
	
	<main class="bg_gray pattern">
		
		<div class="container margin_60_40" style="padding-top:90px;">
		    <div class="row justify-content-center">
		        <div class="col-lg-4">
		        	<div class="sign_up">
		                <div class="head">
		                    <div class="title">
		                    <h3>Đăng kí</h3>
		                </div>
		                </div>
		                <!-- /head -->
		                <form action="sign-up.php" method="post">
		                <div class="main">
		                	<h6>Thông tin đăng kí</h6>
		                	<div class="form-group">
		            			<input class="form-control" type="text"  name="name" placeholder="Họ và tên" required>
		            			<i class="icon_pencil"></i>
		            		</div>
		            		<div class="form-group">
		            			<input class="form-control" type="email" name="email" placeholder="Email Address" required>
		            			<i class="icon_mail"></i>
		            		</div>
		            		<div class="form-group">
		            			<input class="form-control" type="text"  name="username" placeholder="Tên người dùng" required>
		            			<i class="icon_mail"></i>
		            		</div>
		            		<div class="form-group add_bottom_15">
		            			<input class="form-control" placeholder="Password" id="password_sign" type="password"  name="password" required>
		            			<i class="icon_lock"></i>
		            		</div>
		                    <button type="submit" class="btn_1 full-width mb_5">Đăng kí</button>
		                </div></form>
		            </div>
		        </div>
		    </div>
		</div>
	</main>
<?php
   include 'footer.php';
?>