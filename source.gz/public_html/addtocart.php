<?php
include 'config.php';
if(isset($_POST["uid"]) && $_POST["uid"]!= -1)
{
   $uid =  $_POST["uid"];
   $mid =  $_POST["mid"];
$sql="SELECT * FROM menu WHERE id = '$mid'";    
$result = mysqli_query($conn,$sql);
while($menu = mysqli_fetch_assoc($result)){
$name = $menu['name'];
$price = $menu['price'];
$image = $menu['image'];
}
$sql1="SELECT * FROM user WHERE id = '$uid'";    
$result1 = mysqli_query($conn,$sql1);
while($user = mysqli_fetch_assoc($result1)){
$uname = $user['name'];
}

$sql2="SELECT * FROM cart WHERE mid = '$mid'";    
$result2 = mysqli_query($conn,$sql2);
$sl = 1;
while($check = mysqli_fetch_assoc($result2)){
$sl = $check['sl']+1;
}
if($sl==1){
$insert = "INSERT INTO `cart` (mid, uid, name,uname,price,sl,image)
  VALUES ('$mid', '$uid', '$name', '$uname','$price','$sl','$image')";
    
}else{
$insert = "UPDATE  `cart` SET
mid='$mid',
uid ='$uid',
name ='$name',
uname='$uname',
price='$price',
image='$image',
sl ='$sl'
WHERE mid='$mid'
";}    
 $_SESSION['cart']++;
$result = mysqli_query($conn,$insert);

}




?>