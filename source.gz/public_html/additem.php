<?php
include 'config.php';
   if(!isset($_SESSION['admin']))
   {
      header("Location: ./index.php");
   }
   include 'aheader.php';
   ?>


  <!-- /Navigation-->
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Thêm món</li>
      </ol>
		<div class="box_general padding_bottom">
			<div class="header_box version_2">
				<h2><i class="fa fa-file"></i>Thông tin</h2>
			</div>
			<form action="newitem.php" method="post">
			<div class="row">
<div class="col-md-4">
    <div class="form-group">
                <label>Hình ảnh</label>
    <h6>Chọn hình ảnh(png, jpg,...)</h6>
    <input type="file" name="upload_image" id="upload_image" accept="image/*" />
      <div id="uploaded_image"></div>
   </div>   </div>
                  <br>
				<div class="col-md-8">
				<div class="col-md-6">
					<div class="form-group">
						<label>Tên món</label>
						<input type="text" class="form-control" name="name" placeholder="">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label>Menu</label>
						<div class="styled-select">
						<select name="type">
							<option value="1">Món cơm</option>
							<option value="2">Món mỳ</option>
							<option value="3">Món nước</option>
							<option value="4">Đồ uống</option>
							<option value="5">Tráng miệng</option>
						</select>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label>Giá bán(vnđ)</label>
						<input type="number" name="price" class="form-control" placeholder="">
					</div>
				</div>
			</div>
			<!-- /row-->
			<!-- /row-->
		</div>
		  <button type="submit" class="btn btn-success crop_image">Thêm món</button>
		</form>
	  </div>
	  <!-- /.container-fluid-->
   	</div>
    <!-- /.container-wrapper-->
    <div  id="uploadimageModal" tabindex="-1" role="dialog"  style="display:none">
          <div class="modal-body">
  <div id="image_demo" style="width:350px; margin-top:20px"></div>
  <br />
    <br />
    <br/>
 <div style="clear:both"></div></div>
          <div class="modal-footer">
            <button class="btn btn-secondary closeim" data-dismiss="modal">Cancel</button>
            <button class="btn btn-success crop_image">Cắt và lưu</button>
      </div>
    </div>
<?php
   include 'afooter.php';
?>
