<?php
include 'config.php';
   if(!isset($_SESSION['admin']))
   {
      header("Location: ./index.php");
   }
   include 'aheader.php';
 if(!isset($_GET['id'])){
          header("Location: ./index.php");
}
$id=$_GET['id'];
 $sql = "SELECT * FROM menu WHERE id='$id'";
  $result = mysqli_query($conn,$sql);  
  
  if(isset( $_POST['name'])){
$name = $_POST['name'];
$type = $_POST['type'];
$price = $_POST['price'];
$status = $_POST['status'];
if(!isset( $_POST['image'])){
$update = "UPDATE  `menu` SET
name='$name',
type ='$type',
status ='$status',
price='$price'
WHERE id='$id'
";    
}else{
 $image=$_POST['image'];   
$update = "UPDATE  `menu` SET
name='$name',
type ='$type',
status ='$status',
price='$price',
image='$image'
WHERE id='$id'
";}
$result1 = mysqli_query($conn,$update);

if(!$result1 ) {
      echo 'Could not update data: ';
   }else{
   echo ("<script LANGUAGE='JavaScript'>
    window.alert('Sửa thành công');
    window.location.href='./admin.php';
   </script>");}    
}
   ?>

  <!-- /Navigation-->
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Cập nhật món</li>
      </ol>
		<div class="box_general padding_bottom">
			<div class="header_box version_2">
				<h2><i class="fa fa-file"></i>Thông tin</h2>
			</div>
						    <?php 
while($row = mysqli_fetch_assoc($result)){print' 
			<form action="updateitem.php?id='.$row['id'].'" method="post">
			<div class="row">
<div class="col-md-4">
    <div class="form-group">
                <label>Hình ảnh</label>
    <h6>Chọn hình ảnh(png, jpg,...)</h6>
    <input type="file" name="upload_image" id="upload_image" accept="image/*" />
    <img src="'.$row['image'].'" class="img-thumbnail" style="height:150px!important;width:235px!important;" id="tamthoi" />
      <div id="uploaded_image"></div>
   </div>   </div>
                  <br>
				<div class="col-md-8">
				<div class="col-md-6">
					<div class="form-group">
						<label>Tên món</label>
						<input type="text" class="form-control" name="name" value="'.$row['name'].'">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label>Menu</label>
						<div class="styled-select">
						<select name="type">
							<option value="1"';if($row['type']==1){print'selected';}print'>Món cơm</option>
							<option value="2"';if($row['type']==2){print'selected';}print'>Món mỳ</option>
							<option value="3"';if($row['type']==3){print'selected';}print'>Món nước</option>
							<option value="4"';if($row['type']==4){print'selected';}print'>Đồ uống</option>
							<option value="5"';if($row['type']==5){print'selected';}print'>Tráng miệng</option>
						</select>
						</div>
					</div>
				</div>
				
				<div class="col-md-6">
					<div class="form-group">
						<label>Giá bán(vnđ)</label>
						<input type="number" name="price" class="form-control" value="'.$row['price'].'">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label>Trạng thái</label>
						<div class="styled-select">
						<select name="status">
							<option value="1"';if($row['status']==1){print'selected';}print'>còn món</option>
							<option value="0"';if($row['status']==0){print'selected';}print'>tạm hết</option>
						</select>
						</div>
					</div>
				</div>
			</div>
		</div>
		  <button type="submit" class="btn btn-success crop_image">Cập nhật</button></form>';}?>
		
	  </div>
	  <!-- /.container-fluid-->
   	</div>
    <!-- /.container-wrapper-->
    <div  id="uploadimageModal" tabindex="-1" role="dialog"  style="display:none">
          <div class="modal-body">
  <div id="image_demo" style="width:350px; margin-top:20px"></div>
  <br />
    <br />
    <br/>
 <div style="clear:both"></div></div>
          <div class="modal-footer">
            <button class="btn btn-secondary closeim" data-dismiss="modal">Cancel</button>
            <button class="btn btn-success crop_image">Cắt và lưu</button>
      </div>
    </div>
<?php
   include 'afooter.php';
?>
