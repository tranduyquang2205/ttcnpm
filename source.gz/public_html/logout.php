<?php
session_start();
session_destroy();
echo ("<script LANGUAGE='JavaScript'>
    window.alert('Đăng xuất thành công');
    window.location.href='./index.php';
   </script>");
?>