<?php
include 'config.php';
if(isset($_SESSION['admin']))
   {
	header("Location: ./admin.php");
   }
$k=0;
if(isset($_POST['username'])){
	$username = $_POST['username'];
	$password = $_POST['password'];
	$sql ="SELECT * FROM `user` WHERE username='$username' and password = '$password'";
$result = mysqli_query($conn,$sql);
while($row = mysqli_fetch_assoc($result)){
		if($row['level']==1){
        $_SESSION['admin']= 1;	
        		  $_SESSION['id'] = $row['id'];
        		   $_SESSION['cart'] = 0;
        $_SESSION['name']= $row['name'];
		   echo ("<script LANGUAGE='JavaScript'>
    window.alert('Đăng nhập thành công');
    window.location.href='./admin.php';
   </script>");
		}else{
		    $_SESSION['admin']= 0;
		  $_SESSION['name']= $row['name'];
		  $_SESSION['id'] = $row['id'];
		  $_SESSION['cart'] = 0;
		  $uid = $_SESSION['id'];
$sqll="SELECT * FROM cart WHERE uid = '$uid'";  
$resultt = mysqli_query($conn,$sqll);
while($roww = mysqli_fetch_assoc($resultt)){
    $_SESSION['cart']+=$roww['sl'];
}
		    echo ("<script LANGUAGE='JavaScript'>
    window.alert('Đăng nhập thành công');
    window.location.href='./index.php';
   </script>");
		}
}
		    echo ("<script LANGUAGE='JavaScript'>
    window.alert('Sài tài khoản hoặc mật khẩu');
    window.location.href='./index.php';
   </script>");
}
?>