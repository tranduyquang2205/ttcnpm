<?php
function getmenu($type,$conn){
    if(!isset($_SESSION['id'])){
        $_SESSION['id']=-1;
    }
$sql="SELECT * FROM menu WHERE type = '$type'";    
$result = mysqli_query($conn,$sql);      
while($menu = mysqli_fetch_assoc($result)){
$price =number_format($menu['price'],0,",",".").' vnđ';
print '
			    <div class="item">
			        <div class="strip">
			            <figure>
			                <span class="ribbon off">'.$price.'</span>
			                <img src="'.$menu['image'].'" data-src="'.utf8_encode($menu['image']).'" class="owl-lazy" alt="">
			                <a class="strip_info">
			                    <div class="item_title">
			                        <h3>'.$menu['name'].'</h3>
			                    </div>
			                </a>
			            </figure>
			            <ul>
			                <li>';
			                if($menu['status']==1){print'
			                <span class="loc_open">Còn món</span>';}else{
			                    print'
			                <span class="loc_closed">tạm hết</span>';
			                }
			                print '</li>
			                <li>
			                    <button onclick="addtocart('.$menu['id'].','.$_SESSION['id'].')" class="btn_1 btn_scroll"><strong>Thêm</strong></button>
			                </li>
			            </ul>
			        </div>
			    </div>
';
}

}
function agetmenu($type,$conn){
$sql="SELECT * FROM menu WHERE type = '$type'";    
$result = mysqli_query($conn,$sql);      
while($menu = mysqli_fetch_assoc($result)){
    if($menu['type']==1){
        $type="Món cơm";
    }else
     if($menu['type']==1){
        $type="Món mì";
    }else
     if($menu['type']==1){
        $type="Món nước";
    }else
     if($menu['type']==1){
        $type="Đồ uống";
    }
    
$price =number_format($menu['price'],0,",",".").' vnđ';
print '
			    					<li>
						<figure><img src="'.$menu['image'].'" alt=""></figure>
						<h4>'.$menu['name'].' <i class="pending">'.$price.'</i></h4>
						<p><a href="#" class="btn_1 gray"><i class="fa fa-fw fa-envelope"></i> '.$type.'</a></p>
						<ul class="buttons">
							<li><a href="admin/#0" class="btn_1 gray approve"><i class="fa fa-fw fa-check-circle-o"></i> Chỉnh sửa</a></li>
							<li><a href="admin/#0" class="btn_1 gray delete"><i class="fa fa-fw fa-times-circle-o"></i> Xóa</a></li>
						</ul>
					</li>
';
}

}
function getcheckout($uid,$conn){
$thanhtien=0;
$sql="SELECT * FROM cart WHERE uid = '$uid'";    
$result = mysqli_query($conn,$sql);      
while($menu = mysqli_fetch_assoc($result)){
    $thanhtien+=$menu['price']*$menu['sl'];
$price =number_format($menu['price'],0,",",".").' vnđ';
print '
							<li>
								<a >
									<figure>
										<img src="'.$menu['image'].'" data-src="'.$menu['image'].'" alt="" class="lazy">
									</figure>
									<h3>'.$menu['name'].'</h3>
									<small>'.$price.'</small> x '.$menu['sl'].'
									<ul>
										<li><span class="ribbon off">'.number_format($menu['sl']*$menu['price'],0,",",".").' vnđ</span></li>
									</ul>
								</a>
							</li>
';
}
$thanhtien =  number_format($thanhtien,0,",",".").'vnđ';
echo 'Thành tiền: '.$thanhtien;
echo '</br>
<a href="comfirm.php" class="btn_1">Thanh toán</a>';
}

?>