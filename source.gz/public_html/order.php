<?php
   include 'aheader.php';
include 'config.php';
include 'function.php';
   if(!isset($_SESSION['admin']))
   {
      header("Location: ./index.php");
   }
   ?>
   <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Danh sách đơn</li>
      </ol>
		<div class="box_general">
			<div class="header_box">
				<h2 class="d-inline-block">Bookings list</h2>
				<div class="filter">
					<select name="orderby" onchange="agetorder(this.value)" class="selectbox">
						<option value="-1">Tất cả</option>
						<option value="0">Đang chờ</option>
						<option value="1">Đã xong</option>
						<option value="2">Hủy</option>
					</select>
				</div>
			</div>
			<div class="list_general">
				<ul id="txtHint">
				</ul>
			</div>
		</div>
		<!-- /box_general-->
		<!-- /pagination-->
	  </div>
	  <!-- /container-fluid-->
   	</div>
   	    <script>
function agetorder(str) {
  var xhttp;
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("txtHint").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "agetorder.php?type="+str, true);
  xhttp.send();
}
agetorder(-1)
</script>    
<?php
   include 'afooter.php';
?>